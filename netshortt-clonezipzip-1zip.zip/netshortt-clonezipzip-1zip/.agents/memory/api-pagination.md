---
name: API pagination behavior
description: Non-obvious pagination behavior of the two catalog sources.
---

AnyShort's browse endpoint paginates with an opaque cursor returned in `page.next`; passing `offset` does not advance the result set. Reelree's page-number wrapper can return the same catalog records for different page URLs, so it should not be treated as a reliable page source without duplicate detection.

**Why:** Testing the endpoints showed that offset-based requests returned the same first records, while following `page.next` returned a distinct next batch. Reelree reported different page numbers but repeated the same records.

**How to apply:** Use AnyShort's `page.next` as the catalog navigation cursor. Use Reelree for first-page/feature content or details, and never assume its `page=N` response is distinct without comparing record IDs.