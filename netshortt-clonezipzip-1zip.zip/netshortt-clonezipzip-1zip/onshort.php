<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#0b0e17">
  <meta name="description" content="أقسام ONShort في شاشة.">
  <title>ONShort | شاشة</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&family=Manrope:wght@500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body class="onshort-page">
  <div class="ambient ambient-one"></div>
  <div class="ambient ambient-two"></div>
  <header class="site-header">
    <a class="brand" href="index.php" aria-label="شاشة - الرئيسية">
      <span class="brand-mark">ش</span><span class="brand-name">شاشة</span>
    </a>
    <nav class="main-nav" aria-label="التنقل الرئيسي">
      <a href="index.php">الرئيسية</a>
      <a class="active" href="onshort.php">ONShort</a>
    </nav>
    <a class="ghost-button compact-button" href="index.php">العودة للرئيسية</a>
  </header>

  <main class="onshort-main">
    <section class="source-hero">
      <div>
        <p class="section-kicker">مصدر جديد</p>
        <h1>مكتبة <em>ONShort</em></h1>
        <p>تصفح كل الأقسام المتاحة من المصدر في صفحة واحدة، واختر أي مسلسل لبدء المشاهدة.</p>
      </div>
      <div class="source-hero-mark" aria-hidden="true">ON</div>
    </section>
    <div id="onshortSections" class="onshort-sections" aria-live="polite">
      <div class="onshort-loading"><span class="spinner"></span><p>جاري تحميل أقسام ONShort...</p></div>
    </div>
  </main>

  <footer class="site-footer">
    <div class="brand footer-brand"><span class="brand-mark">ش</span><span class="brand-name">شاشة</span></div>
    <span>المصدر: ONShort</span>
    <span class="footer-note">بيانات الأقسام تُحدّث تلقائياً من المصدر.</span>
  </footer>
  <script src="onshort.js"></script>
</body>
</html>