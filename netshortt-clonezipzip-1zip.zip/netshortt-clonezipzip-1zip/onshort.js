const onshortEscape = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
}[char]));

function onshortPoster(item) {
  if (!item.poster) return '<div class="poster-placeholder">ش</div>';
  return `<img src="${onshortEscape(item.poster)}" alt="${onshortEscape(item.title)}" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'poster-placeholder',textContent:'ش'}))">`;
}

function onshortCard(item) {
  const itemUrl = item.url || `index.php#discover`;
  return `
    <article class="series-card onshort-series-card">
      <a href="${onshortEscape(itemUrl)}" target="_blank" rel="noopener">
        <div class="series-poster">
          ${onshortPoster(item)}
          <span class="card-badge">${onshortEscape(item.platform || "ONShort")}</span>
          <span class="card-play"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 5 11 7-11 7V5Z"/></svg></span>
        </div>
        <h3 title="${onshortEscape(item.title)}">${onshortEscape(item.title)}</h3>
        <div class="card-sub"><span>${onshortEscape(item.format || item.platform || "ONShort")}</span><i></i><span>${item.episodes ? `${item.episodes} حلقة` : "مسلسل"}</span></div>
      </a>
    </article>`;
}

function renderOnshortSections(sections) {
  const container = document.querySelector("#onshortSections");
  if (!sections.length) {
    container.innerHTML = '<div class="empty-state"><div class="empty-icon">⌕</div><h3>لا توجد أقسام متاحة</h3><p>تعذر قراءة محتوى المصدر حالياً.</p></div>';
    return;
  }
  container.innerHTML = sections.map((section) => `
    <section class="onshort-section">
      <div class="onshort-section-heading">
        <div><p class="section-kicker">${onshortEscape(section.kicker || "ONSHORT")}</p><h2>${onshortEscape(section.title)}</h2></div>
        <span>${section.count || section.items.length} عمل</span>
      </div>
      <div class="series-grid">${section.items.map(onshortCard).join("")}</div>
    </section>`).join("");
}

async function loadOnshortSections() {
  const response = await fetch("onshort/api.php?action=sections", { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = await response.json();
  if (data.error) throw new Error(data.message || "تعذر تحميل المصدر");
  renderOnshortSections(data.sections || []);
}

loadOnshortSections().catch((error) => {
  document.querySelector("#onshortSections").innerHTML = `
    <div class="empty-state"><div class="empty-icon">!</div><h3>تعذر تحميل المصدر</h3>
    <p>${onshortEscape(error.message)}. حاول تحديث الصفحة بعد قليل.</p></div>`;
});