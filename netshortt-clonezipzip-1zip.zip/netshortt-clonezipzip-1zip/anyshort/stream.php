<?php
declare(strict_types=1);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Range, Origin, Accept, Content-Type');
header('Access-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$url = trim((string)($_GET['url'] ?? ''));
if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
    http_response_code(400);
    echo 'رابط الفيديو غير صالح';
    exit;
}

$parts = parse_url($url);
$host = strtolower((string)($parts['host'] ?? ''));
$allowed = $host === 'v-mps.crazymaplestudios.com'
    || str_ends_with($host, '.tiktokcdn.com')
    || $host === 'tiktokcdn.com';
if (!in_array(strtolower((string)($parts['scheme'] ?? '')), ['http', 'https'], true) || !$allowed) {
    http_response_code(403);
    echo 'مصدر الفيديو غير مسموح';
    exit;
}

function upstream(string $url, ?string $range = null): array {
    $headers = [
        'Accept: */*',
        'Accept-Encoding: identity',
        'Referer: https://anyshort.net/',
        'User-Agent: Mozilla/5.0',
    ];
    if ($range !== null) $headers[] = 'Range: ' . $range;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_ENCODING => '',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    $body = curl_exec($ch);
    $info = curl_getinfo($ch);
    $error = curl_error($ch);
    curl_close($ch);
    return [$body, $info, $error];
}

function absoluteUrl(string $base, string $reference): string {
    if (preg_match('#^https?://#i', $reference)) return $reference;
    $baseParts = parse_url($base);
    $scheme = $baseParts['scheme'] ?? 'https';
    $host = $baseParts['host'] ?? '';
    $port = isset($baseParts['port']) ? ':' . $baseParts['port'] : '';
    if (str_starts_with($reference, '//')) return $scheme . ':' . $reference;
    if (str_starts_with($reference, '/')) return $scheme . '://' . $host . $port . $reference;
    $path = $baseParts['path'] ?? '/';
    $directory = rtrim(str_replace('\\', '/', dirname($path)), '/');
    $combined = ($directory ? $directory . '/' : '/') . $reference;
    $segments = [];
    foreach (explode('/', $combined) as $segment) {
        if ($segment === '' || $segment === '.') continue;
        if ($segment === '..') { array_pop($segments); continue; }
        $segments[] = $segment;
    }
    return $scheme . '://' . $host . $port . '/' . implode('/', $segments);
}

function proxyUrl(string $url): string {
    return 'stream.php?url=' . rawurlencode($url);
}

function rewritePlaylist(string $playlist, string $baseUrl): string {
    $lines = preg_split("/\r\n|\n|\r/", $playlist);
    $rewritten = [];
    foreach ($lines as $line) {
        if (preg_match('/URI="([^"]+)"/i', $line, $match)) {
            $target = absoluteUrl($baseUrl, $match[1]);
            $line = str_replace($match[1], proxyUrl($target), $line);
        } elseif ($line !== '' && !str_starts_with($line, '#')) {
            $line = proxyUrl(absoluteUrl($baseUrl, trim($line)));
        }
        $rewritten[] = $line;
    }
    return implode("\n", $rewritten);
}

$isPlaylist = preg_match('/\.m3u8(?:$|[?#])/i', $url) === 1;
if ($isPlaylist) {
    [$body, $info, $error] = upstream($url);
    if ($body === false || ($info['http_code'] ?? 0) < 200 || ($info['http_code'] ?? 0) >= 400) {
        http_response_code(502);
        echo 'تعذر تحميل قائمة الفيديو';
        exit;
    }
    header('Content-Type: application/vnd.apple.mpegurl');
    header('Cache-Control: no-store');
    echo rewritePlaylist((string)$body, (string)($info['url'] ?? $url));
    exit;
}

$range = $_SERVER['HTTP_RANGE'] ?? null;
if ($range !== null) {
    http_response_code(206);
    header('Accept-Ranges: bytes');
}

$headers = [
    'Accept: */*',
    'Accept-Encoding: identity',
    'Referer: https://anyshort.net/',
    'User-Agent: Mozilla/5.0',
];
if ($range !== null) $headers[] = 'Range: ' . $range;

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 3,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_ENCODING => '',
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_HEADERFUNCTION => static function ($ch, string $line): int {
        $length = strlen($line);
        $trimmed = trim($line);
        if (preg_match('/^Content-(Length|Range):/i', $trimmed) || preg_match('/^Accept-Ranges:/i', $trimmed)) {
            header($trimmed);
        }
        return $length;
    },
    CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk): int {
        echo $chunk;
        flush();
        return strlen($chunk);
    },
]);
header('Content-Type: video/mp4');
header('Cache-Control: no-store');
$ok = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($ok === false || $status >= 400 || $status === 0) {
    if (!headers_sent()) http_response_code(502);
}