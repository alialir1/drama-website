<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: *');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const ONSHORT_HOME = 'https://onshort.net/ar/';
const ONSHORT_CACHE_DIR = __DIR__ . '/.cache/';
const ONSHORT_CACHE_TTL = 300;

if (!is_dir(ONSHORT_CACHE_DIR)) {
    @mkdir(ONSHORT_CACHE_DIR, 0755, true);
}

function jsonOut(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function cachedText(string $key, callable $fetch): string
{
    $file = ONSHORT_CACHE_DIR . md5($key) . '.html';
    if (is_file($file) && (time() - (int) filemtime($file)) < ONSHORT_CACHE_TTL) {
        return (string) file_get_contents($file);
    }

    $body = (string) $fetch();
    if ($body !== '') {
        @file_put_contents($file, $body);
    }
    return $body;
}

function fetchRemote(string $url): string
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_ENCODING => '',
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml',
            'Accept-Language: ar-IQ,ar;q=0.9,en;q=0.7',
            'Referer: https://onshort.net/ar/',
            'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/137 Safari/537.36',
        ],
    ]);
    $body = curl_exec($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($body !== false && $status >= 200 && $status < 400) ? (string) $body : '';
}

function textContent(?DOMNode $node): string
{
    if (!$node) return '';
    return trim(preg_replace('/\s+/u', ' ', $node->textContent ?? '') ?? '');
}

function firstNode(DOMXPath $xpath, string $query, DOMNode $context): ?DOMNode
{
    $nodes = $xpath->query($query, $context);
    return ($nodes && $nodes->length) ? $nodes->item(0) : null;
}

function imageUrl(?DOMNode $image): string
{
    if (!$image instanceof DOMElement) return '';
    foreach (['src', 'data-src', 'data-lazy-src'] as $attribute) {
        $value = trim($image->getAttribute($attribute));
        if ($value !== '') return $value;
    }
    return '';
}

function parseSeriesCard(DOMXPath $xpath, DOMNode $card, string $sectionKey): ?array
{
    if (!$card instanceof DOMElement) return null;
    $link = firstNode($xpath, './/a[contains(concat(" ", normalize-space(@class), " "), " series-card__link ")]', $card);
    $titleNode = firstNode($xpath, './/div[contains(concat(" ", normalize-space(@class), " "), " series-card__copy ")]//h3', $card);
    $image = firstNode($xpath, './/div[contains(concat(" ", normalize-space(@class), " "), " series-card__poster ")]//img', $card);
    $title = textContent($titleNode);
    if ($title === '') return null;

    $episodeText = textContent(firstNode($xpath, './/*[contains(concat(" ", normalize-space(@class), " "), " episode-pill ")]', $card));
    preg_match('/\d+/u', $episodeText, $episodeMatch);
    $format = textContent(firstNode($xpath, './/*[contains(concat(" ", normalize-space(@class), " "), " format-pill ")]', $card));
    $platformNode = firstNode($xpath, './/*[contains(concat(" ", normalize-space(@class), " "), " platform-badge ")]', $card);
    $platform = $platformNode instanceof DOMElement ? trim($platformNode->getAttribute('title')) : '';
    if ($platform === '') {
        $platform = textContent(firstNode($xpath, './/div[contains(concat(" ", normalize-space(@class), " "), " series-card__copy ")]//span', $card));
    }

    return [
        'id' => $card->getAttribute('data-series-card'),
        'title' => $title,
        'url' => $link instanceof DOMElement ? $link->getAttribute('href') : '',
        'poster' => imageUrl($image),
        'episodes' => isset($episodeMatch[0]) ? (int) $episodeMatch[0] : null,
        'platform' => $platform ?: 'ONShort',
        'format' => $format,
        'section' => $sectionKey,
        'source' => 'onshort',
    ];
}

function parseSections(string $html): array
{
    if ($html === '') return [];
    libxml_use_internal_errors(true);
    $document = new DOMDocument();
    $document->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOWARNING | LIBXML_NOERROR);
    libxml_clear_errors();
    $xpath = new DOMXPath($document);
    $sectionNodes = $xpath->query('//section[contains(concat(" ", normalize-space(@class), " "), " app-section ")]');
    $sections = [];
    if (!$sectionNodes) return $sections;

    foreach ($sectionNodes as $section) {
        $heading = textContent(firstNode($xpath, './/h2', $section));
        $kicker = textContent(firstNode($xpath, './/*[contains(concat(" ", normalize-space(@class), " "), " red-kicker ")]', $section));
        if ($heading === '') continue;
        $haystack = mb_strtolower($heading . ' ' . $kicker);
        $classes = $section instanceof DOMElement ? ' ' . $section->getAttribute('class') . ' ' : '';
        $key = str_contains($classes, ' app-section--all ')
            ? 'all'
            : (str_contains($haystack, 'مدبلج') || str_contains($haystack, 'dubbed')
            ? 'dubbed'
            : (str_contains($haystack, 'مترجم') || str_contains($haystack, 'subtitled') ? 'subtitled' : 'latest'));
        $cards = [];
        $cardNodes = $xpath->query('.//article[contains(concat(" ", normalize-space(@class), " "), " series-card ")]', $section);
        if ($cardNodes) {
            foreach ($cardNodes as $card) {
                $parsed = parseSeriesCard($xpath, $card, $key);
                if ($parsed) $cards[] = $parsed;
            }
        }
        $sections[$key] = [
            'key' => $key,
            'kicker' => $kicker,
            'title' => $heading,
            'items' => $cards,
            'count' => count($cards),
        ];
    }

    return array_values($sections);
}

$action = $_GET['action'] ?? 'home';
$html = cachedText('home-ar', fn() => fetchRemote(ONSHORT_HOME));
if ($html === '') {
    jsonOut(['error' => true, 'message' => 'تعذر الاتصال بمصدر ONShort حالياً.'], 502);
}

$sections = parseSections($html);
if ($action === 'sections' || $action === 'home') {
    jsonOut([
        'source' => [
            'key' => 'onshort',
            'name' => 'ONShort',
            'url' => ONSHORT_HOME,
            'description' => 'مسلسلات قصيرة مدبلجة ومترجمة من مصدر ONShort.',
        ],
        'sections' => $sections,
        '_cached' => is_file(ONSHORT_CACHE_DIR . md5('home-ar') . '.html'),
    ]);
}

if ($action === 'section') {
    $key = (string) ($_GET['key'] ?? '');
    foreach ($sections as $section) {
        if ($section['key'] === $key) jsonOut($section);
    }
    jsonOut(['error' => true, 'message' => 'القسم غير موجود.'], 404);
}

jsonOut(['error' => true, 'message' => 'الإجراء غير مدعوم.'], 400);