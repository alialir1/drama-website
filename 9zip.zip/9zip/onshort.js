/* شاشة — واجهة ONShort: تشغيل داخلي كامل، أقسام مع "عرض المزيد"، ومكتبة كل المسلسلات بترقيم صفحات */

const ONSHORT_API = "onshort/api.php";

const osState = {
  allPage: 1, allMax: 1, allLoading: false, pagesCache: new Map(), allPrefetch: new Set(),
  detailPost: null, detailEpisodes: [], detailTitle: "",
  hls: null, currentPost: null, currentEp: 1, currentTime: 0,
  sectionsLoaded: false
};

const osReels = { item: null, episodes: [], sources: new Map(), hls: new Map(), muted: true };

const osEscape = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
}[char]));

async function osJson(url, timeout = 45000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { signal: controller.signal, headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (data.error) throw new Error(data.message || "خطأ من المصدر");
    return data;
  } finally {
    clearTimeout(timer);
  }
}

function osPoster(item) {
  if (item.poster) {
    return `<img src="${osEscape(item.poster)}" alt="${osEscape(item.title)}" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'poster-placeholder',textContent:'ش'}))">`;
  }
  return '<div class="poster-placeholder">ش</div>';
}

function osCard(item) {
  return `
    <article class="series-card onshort-series-card" data-post="${osEscape(item.id)}" role="button" tabindex="0" aria-label="${osEscape(item.title)}">
      <div class="series-poster">
        ${osPoster(item)}
        <span class="card-badge">${osEscape(item.platform || "ONShort")}</span>
        <span class="card-play"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 5 11 7-11 7V5Z"/></svg></span>
      </div>
      <h3 title="${osEscape(item.title)}">${osEscape(item.title)}</h3>
      <div class="card-sub"><span>${osEscape(item.format || item.platform || "ONShort")}</span><i></i><span>${item.episodes ? `${item.episodes} حلقة` : "مسلسل"}</span></div>
    </article>`;
}

function osSkeletons(count = 8) {
  return Array.from({ length: count }, () => '<div class="skeleton-card"></div>').join("");
}

/* ---------------- الأقسام (الصفحة الرئيسية للمصدر) ---------------- */

async function loadOsSections() {
  const container = document.querySelector("#onshortSections");
  try {
    const data = await osJson(`${ONSHORT_API}?action=home`);
    const sections = data.sections || [];
    if (!sections.length) {
      container.innerHTML = '<div class="empty-state"><div class="empty-icon">⌕</div><h3>لا توجد أقسام متاحة</h3><p>تعذر قراءة محتوى المصدر حالياً.</p></div>';
      return;
    }
    container.innerHTML = sections.map((section) => `
      <section class="onshort-section">
        <div class="onshort-section-heading">
          <div><p class="section-kicker">${osEscape(section.kicker || "ONSHORT")}</p><h2>${osEscape(section.title)}</h2></div>
          <span>${section.count || section.items.length} عمل</span>
        </div>
        <div class="series-grid">${section.items.slice(0, 6).map(osCard).join("")}</div>
        <div class="os-section-more"><button class="ghost-button compact-button" data-open-library>عرض المزيد <span>←</span></button></div>
      </section>`).join("");
    container.querySelectorAll(".series-card").forEach((card) => {
       card.addEventListener("click", () => openOsReels(card.dataset.post));
       card.addEventListener("keydown", (event) => { if (event.key === "Enter") openOsReels(card.dataset.post); });
    });
    container.querySelectorAll("[data-open-library]").forEach((button) => button.addEventListener("click", () => showOsLibrary(1)));
    osState.sectionsLoaded = true;
  } catch (error) {
    container.innerHTML = `
      <div class="empty-state"><div class="empty-icon">!</div><h3>تعذر تحميل المصدر</h3>
      <p>${osEscape(error.message)}. حاول تحديث الصفحة بعد قليل.</p></div>`;
  }
}

/* ---------------- مكتبة كل المسلسلات (مع ترقيم الصفحات) ---------------- */

function showOsLibrary(page) {
  document.querySelector("#onshortSections").classList.add("hidden");
  document.querySelector("#osLibrary").classList.remove("hidden");
  document.querySelector("#osHero").classList.add("hidden");
  document.querySelector("#osBackToSections").classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
  loadOsLibraryPage(Number(page) || 1);
}

function showOsSections() {
  document.querySelector("#osLibrary").classList.add("hidden");
  document.querySelector("#onshortSections").classList.remove("hidden");
  document.querySelector("#osHero").classList.remove("hidden");
  document.querySelector("#osBackToSections").classList.add("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function loadOsLibraryPage(page) {
  const grid = document.querySelector("#osLibraryGrid");
  const pagination = document.querySelector("#osPagination");
  osState.allPage = page;
  if (osState.allLoading) return;
  osState.allLoading = true;
  grid.innerHTML = osSkeletons();
  pagination.classList.add("hidden");
  const cachedItems = osState.pagesCache.get(page);
  const items = cachedItems ? [...cachedItems] : [];
  if (!cachedItems) {
    try {
      const data = await osJson(`${ONSHORT_API}?action=series_list&page=${page}`);
      osState.allMax = data.pagination?.max || page;
      items.push(...(data.items || []));
      osState.pagesCache.set(page, items);
    } catch (error) {
      grid.innerHTML = `<div class="empty-state"><div class="empty-icon">!</div><h3>تعذر تحميل الصفحة ${page}</h3><p>${osEscape(error.message)}</p></div>`;
      return;
    }
  } else {
    osState.allMax = Math.max(osState.allMax, page);
  }
  if (!items.length) {
    grid.innerHTML = '<div class="empty-state"><div class="empty-icon">⌕</div><h3>لا توجد أعمال في هذه الصفحة</h3></div>';
    return;
  }
  grid.innerHTML = items.map(osCard).join("");
  grid.querySelectorAll(".series-card").forEach((card) => {
     card.addEventListener("click", () => openOsReels(card.dataset.post));
     card.addEventListener("keydown", (event) => { if (event.key === "Enter") openOsReels(card.dataset.post); });
  });
  renderOsPagination();
  // تحميل مسبق للصفحة التالية لتنقل فوري
  if (page < osState.allMax && !osState.allPrefetch.has(page + 1)) {
    osState.allPrefetch.add(page + 1);
    osJson(`${ONSHORT_API}?action=series_list&page=${page + 1}`).then((next) => {
      if (next.items && next.items.length && !osState.pagesCache.has(page + 1)) {
        osState.pagesCache.set(page + 1, next.items);
      }
    }).catch(() => {});
  }
  osState.allLoading = false;
}

function renderOsPagination() {
  const pagination = document.querySelector("#osPagination");
  const pages = [];
  const add = (value) => { if (!pages.includes(value)) pages.push(value); };
  add(1);
  for (let number = Math.max(2, osState.allPage - 2); number <= Math.min(osState.allMax - 1, osState.allPage + 2); number += 1) add(number);
  if (osState.allMax > 1) add(osState.allMax);
  document.querySelector("#osPageStatus").textContent = `صفحة ${osState.allPage} من ${osState.allMax}`;
  document.querySelector("#osPrevPage").disabled = osState.allPage <= 1;
  document.querySelector("#osNextPage").disabled = osState.allPage >= osState.allMax;
  document.querySelector("#osPageNumbers").innerHTML = pages.map((number, index) => {
    const previous = pages[index - 1];
    const gap = previous && number - previous > 1 ? '<span class="page-gap">…</span>' : "";
    return `${gap}<button class="page-number ${number === osState.allPage ? "active" : ""}" data-page="${number}">${number}</button>`;
  }).join("");
  document.querySelector("#osPageNumbers").querySelectorAll(".page-number").forEach((button) => {
    button.addEventListener("click", () => loadOsLibraryPage(Number(button.dataset.page)));
  });
  pagination.classList.remove("hidden");
}

/* ---------------- تشغيل مباشر داخل مشغل الريلز ---------------- */

function osDestroyReels() {
  osReels.hls.forEach((hls) => hls && hls.destroy());
  osReels.hls.clear();
  osReels.sources.clear();
}

function closeOsReels() {
  osDestroyReels();
  document.querySelector("#reelEpisodePicker")?.classList.add("hidden");
  document.querySelector("#reelsFeed").innerHTML = "";
  document.querySelector("#reelsView").classList.add("hidden");
  document.body.style.overflow = "";
}

async function openOsReels(post, item = null) {
  if (!post) return;
  osDestroyReels();
  document.querySelector("#reelsView").classList.remove("hidden");
  document.body.style.overflow = "hidden";
  document.querySelector("#reelsFeed").innerHTML = '<div class="reels-loading"><span class="spinner"></span><p>جاري تحضير المقاطع...</p></div>';
  try {
    const data = await osJson(`${ONSHORT_API}?action=series&post=${encodeURIComponent(post)}`);
    osReels.item = {
      ...(item || {}),
      id: String(post),
      title: data.title || item?.title || "ONShort",
      poster: data.poster || item?.poster || "",
      description: data.description || item?.description || "",
      platform: item?.platform || (data.transport === "runtime" ? "NetShort" : "ONShort")
    };
    osReels.episodes = (data.episodes || []).map((number) => ({ episode: Number(number), number: Number(number) }));
    renderOsReels();
  } catch (error) {
    document.querySelector("#reelsFeed").innerHTML = `<div class="reels-loading"><strong>تعذر تحميل المقاطع</strong><p>${osEscape(error.message)}</p></div>`;
  }
}

function osReelNumber(episode, index) {
  return episode.episode ?? episode.number ?? index + 1;
}

function renderOsReels() {
  const feed = document.querySelector("#reelsFeed");
  if (!osReels.episodes.length) {
    feed.innerHTML = '<div class="reels-loading"><strong>لا توجد حلقات لهذا العمل</strong></div>';
    return;
  }
  feed.innerHTML = osReels.episodes.map((episode, index) => {
    const number = osReelNumber(episode, index);
    const poster = osReels.item.poster;
    return `<article class="reel-slide" data-index="${index}">
      <div class="reel-media">
        <div class="reel-poster">${poster ? `<img src="${osEscape(poster)}" alt="">` : "ش"}</div>
        <video class="reel-video" playsinline muted loop preload="${index === 0 ? "auto" : "metadata"}" ${poster ? `poster="${osEscape(poster)}"` : ""}></video>
        <div class="reel-status" data-reel-status>جاري تحميل الفيديو...</div><div class="reel-shade"></div>
      </div>
      <button class="reel-sound" data-sound="${index}" aria-label="تشغيل الصوت">🔇</button>
      <div class="reel-top-title"><span>EP${String(number).padStart(2, "0")}</span><small>${osEscape(osReels.item.platform)}</small></div>
      <div class="reel-side-actions">
        <button class="reel-action" data-like aria-label="إعجاب"><span>♥</span><small>إعجاب</small></button>
        <button class="reel-action" data-share aria-label="مشاركة"><span>↗</span><small>مشاركة</small></button>
      </div>
      <div class="reel-caption"><strong>${osEscape(osReels.item.title)}</strong><p>${osEscape(osReels.item.description || `الحلقة ${number} من ${osReels.item.title}`)}</p><div class="reel-progress"><i></i></div></div>
      <div class="reel-episode-bar"><button class="reel-episode-trigger" data-episode-picker="${index}" aria-expanded="false"><strong>EP${String(number).padStart(2, "0")}</strong><span>/ EP${String(osReels.episodes.length).padStart(2, "0")}</span><b>⌃</b></button></div>
    </article>`;
  }).join("");

  const slides = [...feed.querySelectorAll(".reel-slide")];
  slides.forEach((slide, index) => {
    const video = slide.querySelector(".reel-video");
    slide.querySelector("[data-sound]").addEventListener("click", (event) => {
      event.stopPropagation();
      video.muted = !video.muted;
      osReels.muted = video.muted;
      event.currentTarget.textContent = video.muted ? "🔇" : "🔊";
    });
    video.addEventListener("click", () => {
      video.muted = !video.muted;
      osReels.muted = video.muted;
      slide.querySelector("[data-sound]").textContent = video.muted ? "🔇" : "🔊";
    });
    slide.querySelector("[data-like]").addEventListener("click", (event) => event.currentTarget.classList.toggle("liked"));
    slide.querySelector("[data-share]").addEventListener("click", () => navigator.share ? navigator.share({ title: osReels.item.title, text: "شاهد هذا المقطع على شاشة" }).catch(() => {}) : navigator.clipboard?.writeText(location.href));
    slide.querySelector("[data-episode-picker]").addEventListener("click", (event) => {
      event.stopPropagation();
      openOsEpisodePicker(index);
    });
  });
  const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
    const video = entry.target.querySelector(".reel-video");
    if (entry.isIntersecting) osLoadReel(Number(entry.target.dataset.index)).then(() => video.play().catch(() => {}));
    else { video.pause(); video.currentTime = 0; }
  }), { root: feed, threshold: .7 });
  slides.forEach((slide) => observer.observe(slide));
  osLoadReel(0);
}

function osSetReelStatus(slide, text, visible = true) {
  const status = slide?.querySelector("[data-reel-status]");
  if (status) { status.textContent = text; status.classList.toggle("hidden", !visible); }
}

async function osLoadReel(index) {
  const slide = document.querySelector(`.reel-slide[data-index="${index}"]`);
  const episode = osReels.episodes[index];
  if (!slide || !episode || slide.dataset.loaded === "true") return;
  slide.dataset.loaded = "loading";
  try {
    const number = osReelNumber(episode, index);
    const data = await osJson(`${ONSHORT_API}?action=play&post=${encodeURIComponent(osReels.item.id)}&ep=${encodeURIComponent(number)}`, 60000);
    if (!data.url) throw new Error(data.message || "لا يوجد رابط تشغيل");
    const video = slide.querySelector(".reel-video");
    video.muted = osReels.muted;
    const isHls = data.kind === "hls";
    if (isHls && window.Hls && Hls.isSupported()) {
      const hls = new Hls({ enableWorker: true, maxBufferLength: 30, backBufferLength: 30 });
      osReels.hls.set(index, hls);
      hls.loadSource(data.url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}));
    } else {
      video.src = data.url;
      video.load();
    }
    (data.subtitles || []).forEach((sub) => {
      const track = document.createElement("track");
      track.kind = "subtitles"; track.label = sub.label || sub.lang; track.srclang = String(sub.lang || "").split("_")[0]; track.src = sub.url;
      video.appendChild(track);
    });
    osSetReelStatus(slide, "", false);
  } catch (error) {
    osSetReelStatus(slide, error.message || "تعذر تشغيل هذه الحلقة");
  }
  slide.dataset.loaded = "true";
}

function openOsEpisodePicker(activeIndex) {
  const picker = document.querySelector("#reelEpisodePicker");
  document.querySelector("#reelEpisodePickerCount").textContent = `${osReels.episodes.length} حلقة`;
  document.querySelector("#reelEpisodeOptions").innerHTML = osReels.episodes.map((episode, index) => `<button class="${index === activeIndex ? "active" : ""}" data-picker-index="${index}">EP${String(osReelNumber(episode, index)).padStart(2, "0")}</button>`).join("");
  picker.classList.remove("hidden");
  document.querySelectorAll("[data-picker-index]").forEach((button) => button.addEventListener("click", () => {
    document.querySelector(`.reel-slide[data-index="${button.dataset.pickerIndex}"]`)?.scrollIntoView({ behavior: "smooth" });
    picker.classList.add("hidden");
  }));
}

/* ---------------- التشغيل ---------------- */

document.addEventListener("DOMContentLoaded", () => {
  document.querySelector("#osBackToSections").addEventListener("click", showOsSections);
  document.querySelector("#osPrevPage").addEventListener("click", () => { if (osState.allPage > 1) loadOsLibraryPage(osState.allPage - 1); });
  document.querySelector("#osNextPage").addEventListener("click", () => { if (osState.allPage < osState.allMax) loadOsLibraryPage(osState.allPage + 1); });
  document.querySelector("#osLibraryOpen").addEventListener("click", () => showOsLibrary(1));
  document.querySelector("#closeReels").addEventListener("click", closeOsReels);
  document.querySelector("#closeReelEpisodePicker").addEventListener("click", () => document.querySelector("#reelEpisodePicker").classList.add("hidden"));
  document.querySelector("#reelEpisodePicker").addEventListener("click", (event) => {
    if (event.target.id === "reelEpisodePicker") event.currentTarget.classList.add("hidden");
  });
  loadOsSections().then(() => {
    const match = location.hash.match(/#series=(\d+)/);
    if (match) openOsReels(match[1]);
  });
});
